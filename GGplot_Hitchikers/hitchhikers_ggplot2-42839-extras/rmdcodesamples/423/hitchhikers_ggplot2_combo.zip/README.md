# The Hitchhiker's Guide to Ggplot2 in R

This file contains the datasets and rmarkdown files to replicate the plots from our book.

The book is available [here](https://leanpub.com/hitchhikers_ggplot2/overview) 

&#169;2016 [Jodie Burchell](http://github.com/t-redactyl) & [Mauricio Vargas](http://github.com/pachamaltese)
